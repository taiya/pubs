%==========================================================================
%                                                                            
%   SIGGRAPH 2013   
%   Dynamic 2D/3D Registration for the Kinect
%   by Sofien Bouaziz and Mark Pauly, EPFL
%
%   Copyright (C) 2013  LGG, EPFL.
%                                                                            
%==========================================================================
function NonRigidAlignment3D
    build_gui();
    demo(1);
end
%==========================================================================
%----------------------------- Optimization -------------------------------
%==========================================================================
function run(nit)
    global stopnow; stopnow=false;
    global type;
    global X;
    global Y;
    global Z;
    global Ex;
    global NY;
    global w3;
    global w4;
    w1 = 1;
    w2 = 0.1;
    Zo = Z;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Create kd-tree
    kd = KDTreeSearcher(Y); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Initialize linear system ||D^0.5(Av - b)||_2^2 + ||W^0.5v||_2^2
    dim = size(Z,1)*size(Z,2);
    A = sparse(size(Z,1)+6*dim, dim+size(Z,1)+3); 
    A((1+size(Z,1)):(size(Z,1)+dim),1:dim) = speye(dim,dim); 
    A((1+size(Z,1)+dim):(size(Z,1)+2*dim),1:dim) = speye(dim,dim);
    A((1+size(Z,1)+dim):(size(Z,1)+dim+dim/2), dim+2) = -ones(dim/2,1);
    A((1+size(Z,1)+dim+dim/2):(size(Z,1)+2*dim), dim+3) = -ones(dim/2,1);    
    M1 = sparse(size(Z,1), size(Z,1));
    M1 = spdiags(-ones(size(Z,1),1),0,M1);
    M1 = spdiags(ones(size(Z,1),1),1,M1);
    M1(end,1) = 1;    
    M2 = sparse(size(Z,1), size(Z,1));
    M2 = spdiags(-ones(size(Z,1),1),0,M2);
    M2 = spdiags(ones(size(Z,1),1),2,M2);
    M2(end-1,1) = 1;
    M2(end,2) = 1;   
    M = [M1;M1';M2;M2'];   
    A((size(Z,1)+2*dim+1):(size(Z,1)+4*dim),1:size(Z,1)) = M;
    A((size(Z,1)+4*dim+1):end,(size(Z,1)+1):dim) = M;
    b = zeros(size(Z,1)+6*dim,1);     
    D = sparse(size(Z,1)+6*dim, size(Z,1)+6*dim);
    D(1:size(Z,1),1:size(Z,1)) = w1*speye(size(Z,1),size(Z,1));
    D((size(Z,1)+1):(size(Z,1)+dim),(size(Z,1)+1):(size(Z,1)+dim)) = w2*speye(dim,dim);
    W = sparse(dim+size(Z,1)+3, dim+size(Z,1)+3);
    W((dim+1):(dim+3), (dim+1):(dim+3)) = 0.1*speye(3, 3);
    W((dim+4):end,(dim+4):end) = 1*speye(size(Z,1), size(Z,1));
    for it=1:nit
        if(stopnow) return; end;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % kd-tree look-up 
        idz = knnsearch(kd,Z);
        P = Y(idz,:);
        NP = NY(idz,:);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Build linear system
        N = [spdiags(NP(:,1),0,size(NP,1),size(NP,1)), ... 
             spdiags(NP(:,2),0,size(NP,1),size(NP,1))];
        A(1:size(Z,1),1:dim) = N;
        Xr = X;
        Xr(:,1) = -Xr(:,1);
        Xr = fliplr(Xr);
        A((1+size(Z,1)+dim):(size(Z,1)+2*dim),dim+1) = reshape(Xr,dim,1);
        A((size(Z,1)+2*dim+1):(3*dim),(dim+4:end)) = spdiags(Ex(1:size(Z,1),2),0,size(Z,1),size(Z,1));
        A((3*dim+1):(size(Z,1)+3*dim),(dim+4:end)) = spdiags(Ex((1+size(Z,1)):(2*size(Z,1)),2),0,size(Z,1),size(Z,1));
        A((size(Z,1)+3*dim+1):(4*dim),(dim+4:end)) = spdiags(Ex((1+2*size(Z,1)):(3*size(Z,1)),2),0,size(Z,1),size(Z,1));
        A((4*dim+1):(size(Z,1)+4*dim),(dim+4:end)) = spdiags(Ex((1+3*size(Z,1)):end,2),0,size(Z,1),size(Z,1));
        A((size(Z,1)+4*dim+1):(5*dim),(dim+4:end)) = spdiags(-Ex(1:size(Z,1),1),0,size(Z,1),size(Z,1));
        A((5*dim+1):(size(Z,1)+5*dim),(dim+4:end)) = spdiags(-Ex((1+size(Z,1)):(2*size(Z,1)),1),0,size(Z,1),size(Z,1));         
        A((size(Z,1)+5*dim+1):(6*dim),(dim+4:end)) = spdiags(-Ex((1+2*size(Z,1)):(3*size(Z,1)),1),0,size(Z,1),size(Z,1));
        A((6*dim+1):end,(dim+4:end)) = spdiags(-Ex((1+3*size(Z,1)):end,1),0,size(Z,1),size(Z,1)); 
        b(1:size(Z,1)) = N*reshape(P,dim,1);
        b((1+size(Z,1)):(size(Z,1)+dim)) = reshape(P,dim,1);
        b((1+size(Z,1)+dim):(size(Z,1)+2*dim)) = reshape(X,dim,1);
        b((size(Z,1)+2*dim+1):end) = reshape(Ex,dim*4,1);
        D((size(Z,1)+dim+1):(size(Z,1)+2*dim),(size(Z,1)+dim+1):(size(Z,1)+2*dim)) = w3*speye(dim,dim);
        D((size(Z,1)+2*dim+1):end,(size(Z,1)+2*dim+1):end) = w4*speye(dim*4,dim*4);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Solve
        v = (A'*D*A + W)\(A'*D*b);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Extract solution
        Z = reshape(v(1:dim), size(X,1), size(X,2));
        theta = v(dim+1);
        R = [cos(theta) -sin(theta); sin(theta) cos(theta)];
        X = X*R' + repmat(v((dim+2):(dim+3))', [size(X,1),1]);
        for i=1:size(Z,1)
            theta = v(dim+3+i);
            R = [cos(theta) -sin(theta); sin(theta) cos(theta)];
            Ex(i,:) = Ex(i,:)*R';
            Ex(i+size(Z,1),:) = Ex(i+size(Z,1),:)*R';
            Ex(i+2*size(Z,1),:) = Ex(i+2*size(Z,1),:)*R';
            Ex(i+3*size(Z,1),:) = Ex(i+3*size(Z,1),:)*R';
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Show result
        show_contour(Z,Y)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Stopping Criteria
        if(norm(Z-Zo)/size(Z,1) < 1e-6 && type == 1)
            return
        elseif(norm(Z-Zo)/size(Z,1) < 1e-4 && type == 2)
            w3 = w3*0.1;
            w4 = w4*0.8;
        end;
        Zo = Z;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
end
%==========================================================================
%----------------------------- SUBROUTINES --------------------------------
%==========================================================================
function X = corrupt_data(X, offset, theta, noise)
    s = RandStream('mt19937ar','Seed',10);           
    Rot = [cos(theta) -sin(theta); sin(theta) cos(theta)];
    X = X*Rot';
    X = X + repmat(offset, [size(X,1),1]);
    X = X+noise*randn(s,size(X));
end
function c = image_to_contour(file)
    I = im2double(imread(file));
    maxI = max(I(:));
    I = I(:,:,1)/maxI;
    [C,h] = imcontour(I,[.5 .5]);
    delete(h); 
    C = C';
    c = C(2:C(1,2),:);
end
function [X Y] = mean_center_and_normalize(X,Y)
    XnY = [X;Y];
    avg = mean(XnY);
    X = X - repmat(avg, [size(X,1),1]);
    Y = Y - repmat(avg, [size(Y,1),1]);
    XnY = [X;Y]; 
    d = sqrt(max(sum(XnY.^2,2))); 
    X = X./d;
    Y = Y./d;
end
function NY = compute_normal(Y)
    R = [0 -1;1 0];
    Y = Y*R';
    N1 = circshift(Y,1)-Y;
    n = sqrt(sum(N1.^2,2));
    N1(:,1) = N1(:,1)./n;
    N1(:,2) = N1(:,2)./n;
    N2 = Y-circshift(Y,-1);
    n = sqrt(sum(N2.^2,2));
    N2(:,1) = N2(:,1)./n;
    N2(:,2) = N2(:,2)./n;
    NY = (N1+N2)./2;
    n = sqrt(sum(NY.^2,2));
    NY(:,1) = NY(:,1)./n;
    NY(:,2) = NY(:,2)./n;
end
function show_contour(X,Y)
    cla;
    X(end+1,:) = X(1,:);
    Y(end+1,:) = Y(1,:);
    plot(X(:,1), X(:,2), '-', 'color',[ 0  0 .9]);
    plot(Y(:,1), Y(:,2), '-', 'color',[.5 .5  0]);
    drawnow;
end
function show_closest()
    global Y;
    global Z;
    kd = KDTreeSearcher(Y); 
    idz = knnsearch(kd,Z);
    P = Y(idz,:);
    for i=1:size(Z,1)
        plot([Z(i,1) P(i,1)], [Z(i,2) P(i,2)], '-', 'color',[1  0 0]);
    end
    drawnow;
end
%==========================================================================
%--------------------------------- DEMOS ----------------------------------
%==========================================================================
function demo(demoid)
    global X;
    global Y;
    global Z;
    global Ex;
    global NY;
    switch demoid
        case 1, [X Y] = demo1();
        case 2, [X Y] = demo2();
        case 3, [X Y] = demo3();
        case 4, [X Y] = demo4();
    end
    [X Y] = mean_center_and_normalize(X,Y);
    Z = X;
    M1 = sparse(size(Z,1), size(Z,1));
    M1 = spdiags(-ones(size(Z,1),1),0,M1);
    M1 = spdiags(ones(size(Z,1),1),1,M1);
    M1(end,1) = 1;   
    M2 = sparse(size(Z,1), size(Z,1));
    M2 = spdiags(-ones(size(Z,1),1),0,M2);
    M2 = spdiags(ones(size(Z,1),1),2,M2);
    M2(end-1,1) = 1;
    M2(end,2) = 1;    
    M = [M1;M1';M2;M2'];
    Ex = M*X;
    show_contour(X,Y);
    NY = compute_normal(Y);
end
function [X Y] = demo1()
    X = image_to_contour('data/f3.png');
    Y = image_to_contour('data/f4.png');
    X = corrupt_data(X, [-50 10], 0, 0);
    Y = corrupt_data(Y, [0 0], 0, 0);
end
function [X Y] = demo2()
    X = image_to_contour('data/f1.png');
    Y = image_to_contour('data/f2.png');
    X = corrupt_data(X, [0 20], 0, 0);
    Y = corrupt_data(Y, [0  0], 0, 0);
end
function [X Y] = demo3()
    X = image_to_contour('data/f1.png');
    Y = image_to_contour('data/f2.png');
    X = corrupt_data(X, [0 20], 0, 0);
    Y = corrupt_data(Y, [0  0], 0, 5);
end
function [X Y] = demo4()
    X = image_to_contour('data/man2.bmp');
    Y = image_to_contour('data/man11.bmp');
    X = corrupt_data(X, [20 0], 0, 0);
    Y = corrupt_data(Y, [0  0], 0, 0);
end
%==========================================================================
%--------------------------------- GUI ------------------------------------
%==========================================================================
function build_gui()
    figure(1); 
    clf; 
    axis off; 
    axis square; 
    hold on;
    set(gca,'YDir','reverse'); 
    set(gcf,'color','white');
    set(gcf, 'Position', [100, 100, 1024, 768]);
    xlim([-1.1 1.1]);
    ylim([-1.1 1.1]);
    global demoId; demoId = 1;
    global type; type = 1;
    global w3; w3 = 1.0;
    global w4; w4 = 1000000;
    global h3;
    global h4;
    uicontrol('style', 'popupmenu', 'Position', [10 25 100 40], ...
              'string', 'Simple1|Simple2|Noise|Human', 'callback', @doSelectDemo);
    uicontrol('style', 'popupmenu', 'Position', [10 0 100 40], ...
              'string', 'Manual|Auto', 'callback', @doSelectType);
    uicontrol('Style','text',...
              'Position',[130 70 120 20],...
              'String','Global Rigidity');
    h3 = uicontrol('Style', 'slider', 'Min', 0.01, 'Max', 100, 'Value', w3,...
              'Position', [130 50 120 20], 'callback',@doChangeWeight3);
    uicontrol('Style','text',...
              'Position',[130 30 120 20],...
              'String','Local Rigidity');
    h4 = uicontrol('Style', 'slider', 'Min', 1, 'Max', 1000000, 'Value', w4,...
              'Position', [130 5 120 20], 'callback',@doChangeWeight4);
    uicontrol('style', 'pushb', 'Position', [280 20 60 40], ...
              'string', 'Run', 'callback', @doRun);
    uicontrol('style', 'pushb', 'Position', [350 20 60 40], ...
              'string', 'Step', 'callback', @doStep);
    uicontrol('style', 'pushb', 'Position', [420 20 60 40], ...
              'string', 'Abort', 'callback', @doAbort);
    uicontrol('style', 'pushb', 'Position', [490 20 60 40], ...
              'string', 'Reset', 'callback', @doReset);
    uicontrol('style', 'pushb', 'Position', [560 20 60 40], ...
              'string', 'Closest', 'callback', @doClosest);
end
function doChangeWeight3(h,e)
    global w3;
    w3 = get(h,'value');
end
function doChangeWeight4(h,e)
    global w4;
    w4 = get(h,'value');
end
function doSelectDemo(h,e) 
    global stopnow; stopnow = true;
    global demoId; 
    global w3;
    global w4;
    global h3;
    global h4;
    demoId = get(h,'Value');
    w3 = get(h3,'value');
    w4 = get(h4,'value');
    demo(demoId)
end
function doSelectType(h,e) 
    global type; type = get(h,'Value');
end
function doRun(h,e) 
    global stopnow; stopnow = true;
    run(1000);
end
function doStep(h,e) 
    global stopnow; stopnow = true;
    run(1);
end
function doAbort(h,e) 
    global stopnow; stopnow = true;
end
function doClosest(h,e) 
    global stopnow; stopnow = true;
    show_closest();
end
function doReset(h,e) 
    global stopnow; stopnow = true;
    global demoId;
    global w3;
    global w4;
    global h3;
    global h4;
    w3 = get(h3,'value');
    w4 = get(h4,'value');
    demo(demoId)
end
%==========================================================================