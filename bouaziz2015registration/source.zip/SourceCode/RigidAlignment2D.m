%==========================================================================
%                                                                            
%   SIGGRAPH 2013   
%   Dynamic 2D/3D Registration for the Kinect
%   by Sofien Bouaziz and Mark Pauly, EPFL
%
%   Copyright (C) 2013  LGG, EPFL.
%                                                                            
%==========================================================================
function RigidAlignment2D
    build_gui();
    demo();
end
%==========================================================================
%----------------------------- Optimization -------------------------------
%==========================================================================
function run(nit)
    global stopnow; stopnow=false;
    global X;
    global Z;
    global I;
    global Ix;
    global J;
    global Gx;
    global Gy;
    global RI;
    global tI;
    w1 = 1;
    w2=10;
    Zo = Z;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Initialize linear system ||D^0.5(Av - b)||_2^2
    dim = size(Z,1)*size(Z,2);
    A = sparse(size(Z,1)+dim, dim+3); 
    A((1+size(Z,1)):end,1:dim) = speye(dim,dim);
    A((1+size(Z,1)):(size(Z,1)+dim/2), end-1) = -ones(dim/2,1);
    A((1+size(Z,1)+dim/2):end, end) = -ones(dim/2,1);
    b = zeros(size(Z,1)+dim,1);
    D = sparse(size(Z,1)+dim, size(Z,1)+dim);
    D(1:size(Z,1),1:size(Z,1)) = w1*speye(size(Z,1),size(Z,1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for it=1:nit
        if(stopnow) return; end;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Build linear system
        Jz = interp2(J,Z(:,1),Z(:,2));
        Gxz = interp2(Gx,Z(:,1),Z(:,2));
        Gyz = interp2(Gy,Z(:,1),Z(:,2));
        G = [spdiags(Gxz,0,size(Gxz,1),size(Gxz,1)), ... 
             spdiags(Gyz,0,size(Gyz,1),size(Gyz,1))];
        A(1:size(Z,1),1:dim) = G;
        b(1:size(Z,1)) = Ix-Jz+G*reshape(Z,dim,1);
        b((1+size(Z,1)):end) = reshape(X,dim,1);
        Xr = X;
        Xr(:,1) = -Xr(:,1);
        Xr = fliplr(Xr);
        A((1+size(Z,1)):end,end-2) = reshape(Xr,dim,1);
        D((size(Z,1)+1):end,(size(Z,1)+1):end) = w2*speye(dim,dim);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Solve
        v = (A'*D*A)\(A'*D*b);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Extract solution
        Z = reshape(v(1:dim), size(X,1), size(X,2));
        theta = v(end-2);
        R = [cos(theta), -sin(theta); sin(theta) cos(theta)];
        t = v((end-1):end);
        X = X*R' + repmat(t', [size(X,1),1]);
        RI = R*RI;
        tI = R*tI + t;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Show result every 10 iterations
        if(mod(it-1,9) == 0)
            M = maketform('affine',[RI tI; 0 0 1]');
            B = findbounds(M,[1 1; size(J)]); 
            B(1,:) = [1 1]; 
            I = imtransform(J,M,'XData',B(:,2)','YData',B(:,1)');
            show_middle();
            show_right();
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Stopping Criteria
        if(norm(Z-Zo)/size(Z,1) < 1e-9) return; end;
        Zo = Z;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
end
%==========================================================================
%----------------------------- SUBROUTINES --------------------------------
%==========================================================================
function show_demo()
    show_left();
    show_middle()
    show_right();
end
function show_left()
    global Y;
    global J;
    subplottight(1,3,1);
    cla;
    imshow(J,'border','tight'); hold on;
    plot(Y(:,1),Y(:,2),'bx');
    drawnow;
end
function show_middle()
    global Y;
    global Z;
    global J;
    subplottight(1,3,2); 
    cla;
    imshow(J,'border','tight'); hold on;
    plot(Y(:,1),Y(:,2),'bx');
    plot(Z(:,1),Z(:,2),'gx');
    drawnow;
end
function show_right()
    global Z;
    global I;
    subplottight(1,3,3); 
    cla;
    imshow(I,'border','tight'); hold on;
    plot(Z(:,1),Z(:,2),'gx');
    drawnow;
    
end
function subplottight(n,m,i)
    [c,r] = ind2sub([m n], i);
    subplot('Position', [(c-1)/m, (r-1)/n, 1/m, 1/n]);
end
%==========================================================================
%--------------------------------- DEMOS ----------------------------------
%==========================================================================
function demo()
    global X;
    global Y;
    global Z;
    global I;
    global Ix;
    global J;
    global Gx;
    global Gy;
    global RI;
    global tI;
    F = fspecial('gaussian',[5 5],5);
    J = im2double(rgb2gray(imread('data/lena.bmp')));
    J = imfilter(J, F, 'replicate');
    I = J;
    s = RandStream('mt19937ar','Seed',10);  
    Y = randi(s,[-round(size(J,1)/2.5), round(size(J,1)/2.5)], 200, 2);
    Y = Y + repmat([size(J,1)/2 size(J,1)/2], [size(Y,1),1]);
    theta = -0.08;
    tI = [4;4];
    RI = [cos(theta) -sin(theta); sin(theta) cos(theta)];
    X = Y*RI' + repmat(tI', [size(Y,1),1]);
    Ix = interp2(J,Y(:,1),Y(:,2));
    [Gx,Gy] = imgradientxy(J);
    Z = X;
    show_demo();
    M = maketform('affine',[RI tI; 0 0 1]');
    B = findbounds(M,[1 1; size(J)]); 
    B(1,:) = [1 1]; 
    I = imtransform(J,M,'XData',B(:,2)','YData',B(:,1)');
    show_right();
end
%==========================================================================
%--------------------------------- GUI ------------------------------------
%==========================================================================
function build_gui()
    figure(1); 
    clf; 
    axis off; 
    axis square; 
    hold on;
    set(gca,'YDir','reverse'); 
    set(gcf,'color','white');
    set(gcf, 'Position', [100, 100, 1024, 768]);
    xlim([-1.1 1.1]);
    ylim([-1.1 1.1]);
    uicontrol('style', 'pushb', 'Position', [30 20 60 40], ...
              'string', 'Run', 'callback', @doRun);
    uicontrol('style', 'pushb', 'Position', [100 20 60 40], ...
              'string', 'Step', 'callback', @doStep);
    uicontrol('style', 'pushb', 'Position', [170 20 60 40], ...
              'string', 'Abort', 'callback', @doAbort);
    uicontrol('style', 'pushb', 'Position', [240 20 60 40], ...
              'string', 'Reset', 'callback', @doReset);
end
function doRun(h,e) 
    global stopnow; stopnow = true;
    run(1000);
end
function doStep(h,e) 
    global stopnow; stopnow = true;
    run(1);
end
function doAbort(h,e) 
    global stopnow; stopnow = true;
end
function doReset(h,e) 
    global stopnow; stopnow = true;
    demo()
end
%==========================================================================