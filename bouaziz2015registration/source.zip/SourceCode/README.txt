%==========================================================================
%   Dynamic 2D/3D Registration
%   by Sofien Bouaziz and Andrea Tagliasacchi and Mark Pauly, EPFL                                                                           
%==========================================================================

Some of the data used in these matlab examples are taken from the mythological creatures 2D dataset (http://tosca.cs.technion.ac.il/book/resources_data.html) and from the MPEG7 CE Shape-1 Part B dataset (http://www.imageprocessingplace.com/root_files_V3/image_databases.htm).