%==========================================================================
%                                                                            
%   SIGGRAPH 2013   
%   Dynamic 2D/3D Registration for the Kinect
%   by Sofien Bouaziz and Mark Pauly, EPFL
%
%   Copyright (C) 2013  LGG, EPFL.
%                                                                            
%==========================================================================
function RigidAlignment3D
    build_gui();
    demo(1);
end
%==========================================================================
%----------------------------- Optimization -------------------------------
%==========================================================================
function run(nit)
    global type;
    if(type == 1)
        AlignPoint(nit);
    else
        AlignPlane(nit);
    end
end
%==========================================================================
function AlignPoint(nit)
    global stopnow; stopnow=false;
    global demoId;
    global X;
    global Y;
    global Z;
    global NY;
    global w2;
    w1 = 1;
    Zo = Z;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Create kd-tree
    kd = KDTreeSearcher(Y); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Initialize linear system ||D^0.5(Av - b)||_2^2
    dim = size(Z,1)*size(Z,2);
    A = sparse(2*dim, dim+3); 
    A(1:dim,1:dim) = speye(dim,dim);
    A((1+dim):end,1:dim) = speye(dim,dim);
    A((1+dim):(dim+dim/2), end-1) = -ones(dim/2,1);
    A((1+dim+dim/2):end, end) = -ones(dim/2,1);
    b = zeros(2*dim,1);
    D = sparse(2*dim, 2*dim);
    D(1:dim,1:dim) = w1*speye(dim,dim);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for it=1:nit
        if(stopnow) return; end;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % kd-tree look-up 
        idz = knnsearch(kd,Z); 
        P = Y(idz,:);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Build linear system
        b(1:dim) = reshape(P,dim,1);
        b((1+dim):end) = reshape(X,dim,1);
        Xr = X;
        Xr(:,1) = -Xr(:,1);
        Xr = fliplr(Xr);
        A((1+dim):end,end-2) = reshape(Xr,dim,1);
        D((dim+1):end,(dim+1):end) = w2*speye(dim,dim);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Solve
        v = (A'*D*A)\(A'*D*b);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Extract solution
        Z = reshape(v(1:dim), size(X,1), size(X,2));
        theta = v(end-2);
        R = [cos(theta), -sin(theta); sin(theta) cos(theta)];
        X = X*R' + repmat(v((end-1):end)', [size(X,1),1]);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Show result
        show_contour(Z,Y,demoId==2)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Stopping Criteria
        if(norm(Z-Zo)/size(Z,1) < 1e-6) return; end;
        Zo = Z;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
end
%==========================================================================
function AlignPlane(nit)
    global stopnow; stopnow=false;
    global demoId;
    global X;
    global Y;
    global Z;
    global NY;
    global w2;
    w1 = 1;
    Zo = Z;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Create kd-tree
    kd = KDTreeSearcher(Y); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Initialize linear system ||D^0.5(Av - b)||_2^2
    dim = size(Z,1)*size(Z,2);
    A = sparse(size(Z,1)+dim, dim+3); 
    A((1+size(Z,1)):end,1:dim) = speye(dim,dim);
    A((1+size(Z,1)):(size(Z,1)+dim/2), end-1) = -ones(dim/2,1);
    A((1+size(Z,1)+dim/2):end, end) = -ones(dim/2,1);
    b = zeros(size(Z,1)+dim,1);
    D = sparse(size(Z,1)+dim, size(Z,1)+dim);
    D(1:size(Z,1),1:size(Z,1)) = w1*speye(size(Z,1),size(Z,1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for it=1:nit
        if(stopnow) return; end;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % kd-tree look-up 
        idz = knnsearch(kd,Z);
        P = Y(idz,:);
        NP = NY(idz,:);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Build linear system
        N = [spdiags(NP(:,1),0,size(NP,1),size(NP,1)), ... 
             spdiags(NP(:,2),0,size(NP,1),size(NP,1))];
        A(1:size(Z,1),1:dim) = N;
        b(1:size(Z,1)) = N*reshape(P,dim,1);
        b((1+size(Z,1)):end) = reshape(X,dim,1);
        Xr = X;
        Xr(:,1) = -Xr(:,1);
        Xr = fliplr(Xr);
        A((1+size(Z,1)):end,end-2) = reshape(Xr,dim,1);
        D((size(Z,1)+1):end,(size(Z,1)+1):end) = w2*speye(dim,dim);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Solve
        v = (A'*D*A)\(A'*D*b);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Extract solution
        Z = reshape(v(1:dim), size(X,1), size(X,2));
        theta = v(end-2);
        R = [cos(theta), -sin(theta); sin(theta) cos(theta)];
        X = X*R' + repmat(v((end-1):end)', [size(X,1),1]);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Show result
        show_contour(Z,Y,demoId==2)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Stopping Criteria
        if(norm(Z-Zo)/size(Z,1) < 1e-6) return; end;
        Zo = Z;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
end
%==========================================================================
%----------------------------- SUBROUTINES --------------------------------
%==========================================================================
function X = corrupt_data(X, offset, theta, noise)
    s = RandStream('mt19937ar','Seed',10);           
    Rot = [cos(theta) -sin(theta); sin(theta) cos(theta)];
    X = X*Rot';
    X = X + repmat(offset, [size(X,1),1]);
    X = X+noise*randn(s,size(X));
end
function c = image_to_contour(file)
    I = im2double(imread(file));
    maxI = max(I(:));
    I = I(:,:,1)/maxI;
    [C,h] = imcontour(I,[.5 .5]);
    delete(h); 
    C = C';
    c = C(2:C(1,2),:);
end
function [X Y] = mean_center_and_normalize(X,Y)
    XnY = [X;Y];
    avg = mean(XnY);
    X = X - repmat(avg, [size(X,1),1]);
    Y = Y - repmat(avg, [size(Y,1),1]);
    XnY = [X;Y]; 
    d = sqrt(max(sum(XnY.^2,2))); 
    X = X./d;
    Y = Y./d;
end
function NY = compute_normal(Y)
    R = [0 -1;1 0];
    Y = Y*R';
    N1 = circshift(Y,1)-Y;
    n = sqrt(sum(N1.^2,2));
    N1(:,1) = N1(:,1)./n;
    N1(:,2) = N1(:,2)./n;
    N2 = Y-circshift(Y,-1);
    n = sqrt(sum(N2.^2,2));
    N2(:,1) = N2(:,1)./n;
    N2(:,2) = N2(:,2)./n;
    NY = (N1+N2)./2;
    n = sqrt(sum(NY.^2,2));
    NY(:,1) = NY(:,1)./n;
    NY(:,2) = NY(:,2)./n;
end
function show_contour(X,Y,m)
    cla;
    X(end+1,:) = X(1,:);
    Y(end+1,:) = Y(1,:);
    if(m)
        plot(X(:,1), X(:,2), 'o', 'color',[ 0  0 .9]);
        plot(Y(:,1), Y(:,2), 'o', 'color',[.5 .5  0]);
    else
        plot(X(:,1), X(:,2), '-', 'color',[ 0  0 .9]);
        plot(Y(:,1), Y(:,2), '-', 'color',[.5 .5  0]);
    end
    drawnow;
end
function show_closest()
    global Y;
    global Z;
    kd = KDTreeSearcher(Y); 
    idz = knnsearch(kd,Z);
    P = Y(idz,:);
    for i=1:size(Z,1)
        plot([Z(i,1) P(i,1)], [Z(i,2) P(i,2)], '-', 'color',[1  0 0]);
    end
    drawnow;
end
function show_bar(pct)
    xoff = 1.0;
    patch([xoff xoff+0.1 xoff+0.1 xoff],[1 1 1-pct 1-pct],[0,0,.9]);
    patch([xoff xoff+0.1 xoff+0.1 xoff],[0 0 1 1],[1,1,1],'FaceColor','none');
    drawnow
end
%==========================================================================
%--------------------------------- DEMOS ----------------------------------
%==========================================================================
function demo(demoid)
    global X;
    global Y;
    global Z;
    global NY;
    switch demoid
        case 1, [X Y] = demo1();
        case 2, [X Y] = demo2();
        case 3, [X Y] = demo3();
        case 4, [X Y] = demo4();
        case 5, [X Y] = demo5();
        case 6, [X Y] = demo6();
    end
    [X Y] = mean_center_and_normalize(X,Y);
    Z = X;
    show_contour(X,Y,demoid==2);
    NY = compute_normal(Y); 
end
function [X Y] = demo1()
    X = image_to_contour('data/man5.bmp');
    Y = image_to_contour('data/man5.bmp');
    X = corrupt_data(X, [-50 10], 0, 0);
    Y = corrupt_data(Y, [0 0], 0, 0);
end
function [X Y] = demo2()
    X = image_to_contour('data/lizzard-4.gif');
    Y = image_to_contour('data/lizzard-4.gif');
    s = RandStream('mt19937ar','Seed',10); 
    q = randperm(s, size(X,1),round(size(X,1)/1.1));
    X(q,:) = [];
    Y(q,:) = [];
    X = corrupt_data(X, [0 20], 0.5, 0);
    Y = corrupt_data(Y, [0  0], 0, 0);
end
function [X Y] = demo3()
    X = image_to_contour('data/horse5.bmp');
    Y = image_to_contour('data/horse5.bmp'); 
    X = corrupt_data(X, [-30 0], 0, 0);
    Y = corrupt_data(Y, [0 0], 0.9, 0);
end
function [X Y] = demo4()
    X = image_to_contour('data/sym2.png');
    X = X - repmat(mean(X), [size(X,1),1]);
    Y = image_to_contour('data/sym.png');
    Y = Y - repmat(mean(Y), [size(Y,1),1]);
    X = corrupt_data(X, [0 -200], 0, 0);
    Y = corrupt_data(Y, [0 0], 0.2, 0);
end
function [X Y] = demo5()
    X = image_to_contour('data/sym2.png');
    X = X - repmat(mean(X), [size(X,1),1]);
    Y = image_to_contour('data/sym.png');
    Y = Y - repmat(mean(Y), [size(Y,1),1]);
    X = corrupt_data(X, [200 0], 1.8, 0);
    Y = corrupt_data(Y, [0 0], 0, 0);
end
function [X Y] = demo6()
    X = image_to_contour('data/horse5.bmp');
    Y = image_to_contour('data/horse5.bmp'); 
    X = corrupt_data(X, [-30 0], 0, 3);
    Y = corrupt_data(Y, [0 0], 0.5, 0);
end
%==========================================================================
%--------------------------------- GUI ------------------------------------
%==========================================================================
function build_gui()
    figure(1); 
    clf; 
    axis off; 
    axis square; 
    hold on;
    set(gca,'YDir','reverse'); 
    set(gcf,'color','white');
    set(gcf, 'Position', [100, 100, 1024, 768]);
    xlim([-1.1 1.1]);
    ylim([-1.1 1.1]);
    global type; type = 1;
    global demoId; demoId = 1;
    global w2; w2=10;
    uicontrol('style', 'popupmenu', 'Position', [10 25 100 40], ...
              'string', 'Simple|Subsample|Failure|Symmetric|Symmetric2|Noise', ... 
              'callback', @doSelectDemo);
    uicontrol('style', 'popupmenu', 'Position', [10 0 100 40], ...
              'string', 'Point|Plane', 'callback', @doSelectType);
    uicontrol('Style','text',...
              'Position',[130 45 120 20],...
              'String','Rigidity');
    uicontrol('Style', 'slider', 'Min', 1, 'Max', 100, 'Value', w2,...
              'Position', [130 20 120 20], 'callback',@doChangeWeight);
    uicontrol('style', 'pushb', 'Position', [280 20 60 40], ...
              'string', 'Run', 'callback', @doRun);
    uicontrol('style', 'pushb', 'Position', [350 20 60 40], ...
              'string', 'Step', 'callback', @doStep);
    uicontrol('style', 'pushb', 'Position', [420 20 60 40], ...
              'string', 'Abort', 'callback', @doAbort);
    uicontrol('style', 'pushb', 'Position', [490 20 60 40], ...
              'string', 'Reset', 'callback', @doReset);
    uicontrol('style', 'pushb', 'Position', [560 20 60 40], ...
              'string', 'Closest', 'callback', @doClosest);
end
function doChangeWeight(h,e)
    global w2;
    w2 = get(h,'value');
end
function doSelectDemo(h,e) 
    global demoId;
    global stopnow; stopnow = true;
    demoId = get(h,'Value');
    demo(demoId)
end
function doSelectType(h,e) 
    global stopnow; stopnow = true;
    global type; type = get(h,'Value');
end
function doRun(h,e) 
    global stopnow; stopnow = true;
    run(1000);
end
function doStep(h,e) 
    global stopnow; stopnow = true;
    run(1);
end
function doAbort(h,e) 
    global stopnow; stopnow = true;
end
function doClosest(h,e) 
    global stopnow; stopnow = true;
    show_closest();
end
function doReset(h,e) 
    global stopnow; stopnow = true;
    global demoId;
    demo(demoId)
end
%==========================================================================